/*
 * package com.virtusa.music.controller;
 * 
 * import java.util.ArrayList; import java.util.Date; import java.util.List;
 * 
 * import org.junit.jupiter.api.Test; import org.mockito.InjectMocks; import
 * org.mockito.Mock; import
 * org.springframework.boot.test.context.SpringBootTest; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.http.ResponseEntity;
 * 
 * import com.virtusa.music.entity.Album; import
 * com.virtusa.music.model.AlbumResponse; import
 * com.virtusa.music.service.AlbumService;
 * 
 * @SpringBootTest public class MusicApplicationControllerTest {
 * 
 * 
 * @InjectMocks MusicController controller;
 * 
 * @Mock AlbumService service;
 * 
 * @Test public void whenArtistAddedThenMusicAppShouldReturnSuccess() {
 * ResponseEntity<AlbumResponse> responseEntity; AlbumResponse albumResponse;
 * Album album = new Album(); List<Album> albums = new ArrayList<Album>();
 * album.setId(10001); album.setArtist("Naresh"); album.setGenre("AAAA");
 * album.setReleaseYear("2020"); album.setTitle("Nenu Nuvvu");
 * album.setAlbumId("XXX101"); albumResponse = new AlbumResponse(new
 * Date(System.currentTimeMillis()), "MUSIC-SUCCESS",
 * "ADDED ARTIST TO MUSIC DB..", String.valueOf(HttpStatus.OK), albums);
 * responseEntity = new ResponseEntity<AlbumResponse>(albumResponse,
 * HttpStatus.OK); //controller.add(album);
 * 
 * }
 * 
 * @Test public void
 * whenRequestedToReturnArtistThenMusicAppShouldReturnSuccess() {
 * ResponseEntity<AlbumResponse> responseEntity; AlbumResponse albumResponse;
 * Album album = new Album(); List<Album> albums = new ArrayList<Album>();
 * album.setId(10001); album.setArtist("Naresh"); album.setGenre("AAAA");
 * album.setReleaseYear("2020"); album.setTitle("Nenu Nuvvu");
 * album.setAlbumId("XXX101"); albums.add(album); albumResponse = new
 * AlbumResponse(new Date(System.currentTimeMillis()), "MUSIC-SUCCESS",
 * "MUSIC API RETURNED WITH ARTISTS..", String.valueOf(HttpStatus.OK), albums);
 * responseEntity = new ResponseEntity<AlbumResponse>(albumResponse,
 * HttpStatus.OK); //ResponseEntity<AlbumResponse> actualResponseEntity =
 * controller.getAlbums();
 * 
 * }
 * 
 * }
 */