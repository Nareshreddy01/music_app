package com.virtusa.music.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.virtusa.music.entity.Album;
import com.virtusa.music.exception.AlbumNotFoundException;
import com.virtusa.music.repository.MusicRepository;
import com.virtusa.music.service.AlbumService;

@Service
public class AlbumServiceImpl implements AlbumService {
	
	@Autowired
	private MusicRepository repository;
	
	public List<Album> getAlbums() {
		List<Album> albums = repository.findAll();
		return albums;
	}
	
	public Album saveAlbum(final Album album) {
		return repository.save(album);
	}
	
	public Album updateAlbum(final String artistId) {
		Album album;
		try {
			album = repository.findById(artistId).get();
		} catch (Exception e) {
			throw new AlbumNotFoundException("Album not found in database entry".concat(artistId));
		}
		return repository.save(album);
	}

}
