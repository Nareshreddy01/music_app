package com.virtusa.music.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.virtusa.music.entity.Album;
import com.virtusa.music.exception.AlbumNotFoundException;
import com.virtusa.music.exception.MusicCommonException;
import com.virtusa.music.model.AlbumResponse;
import com.virtusa.music.service.AlbumService;
import javax.validation.Valid;

@RestController
@RequestMapping("/music")
public class MusicController {

	private static final Logger logger = LoggerFactory.getLogger(MusicController.class);
	
	@Autowired
	private AlbumService albumService;

    @GetMapping(path = "/artists", produces = "application/json")
    public ResponseEntity<AlbumResponse> getAlbums() {
    	ResponseEntity<AlbumResponse> responseEntity;
    	try {
    		List<Album> albums = albumService.getAlbums();
    		AlbumResponse albumResponse;
    		if (albums != null && !albums.isEmpty()) {
    			logger.info("Total Albums {}", albums.size());
    			albumResponse = new AlbumResponse(new Date(System.currentTimeMillis()), "MUSIC-SUCCESS", "MUSIC API RETURNED WITH ARTISTS..",
    					String.valueOf(HttpStatus.OK), albums);
    			responseEntity = new ResponseEntity<AlbumResponse>(albumResponse, HttpStatus.OK);	
			} else {
				logger.info("Album has empty records");
				albumResponse = new AlbumResponse(new Date(System.currentTimeMillis()), "MUSIC-SUCCESS", "MUSIC API RETURNED WITH EMPTY ARTISTS..",
    					String.valueOf(HttpStatus.NOT_FOUND), albums);
				responseEntity = new ResponseEntity<AlbumResponse>(albumResponse, HttpStatus.NOT_FOUND);
			}
    		
    	} catch (Exception e) {
			throw new AlbumNotFoundException("Album not found in database entry.");
		}
        return responseEntity;
    }

    @PostMapping(path = "/artists", produces = "application/json")
    public ResponseEntity<AlbumResponse> add(@RequestBody @Valid Album album) throws MusicCommonException {
    	ResponseEntity<AlbumResponse> responseEntity;
    	List<Album> albums = new ArrayList<Album>();
    	if (album == null) {
			throw new MusicCommonException("Bad Request");
		}
        logger.info("Adding album {} ", album.getId());
        Album responseAlbum = albumService.saveAlbum(album);
        albums.add(responseAlbum);
        AlbumResponse albumResponse = new AlbumResponse(new Date(System.currentTimeMillis()), "MUSIC-SUCCESS", "ARTIST ADDED TO MUSIC STORE..",
				String.valueOf(HttpStatus.OK), albums);
        responseEntity = new ResponseEntity<AlbumResponse>(albumResponse, HttpStatus.OK);
        return responseEntity;
    }

    @PutMapping(path = "/artists/{artistId}", produces = "application/json")
    public ResponseEntity<AlbumResponse> update(@PathVariable String artistdId) throws MusicCommonException {
    	ResponseEntity<AlbumResponse> responseEntity;
    	List<Album> albums = new ArrayList<Album>();
        if (artistdId == null || artistdId.isEmpty()) {
        	throw new MusicCommonException("Bad Request");
		}
        logger.info("Updating album {} ", artistdId);
        Album album = albumService.updateAlbum(artistdId);
        albums.add(album);
        AlbumResponse albumResponse = new AlbumResponse(new Date(System.currentTimeMillis()), "MUSIC-SUCCESS", "ARTIST RECORD UPDATED TO MUSIC STORE..",
				String.valueOf(HttpStatus.OK), albums);
        responseEntity = new ResponseEntity<AlbumResponse>(albumResponse, HttpStatus.OK);
        return responseEntity;
    }

}
