package com.virtusa.music.model;

import java.util.Date;
import java.util.List;

import com.virtusa.music.entity.Album;

public class AlbumResponse {

	private Date timestamp;

	private String mensaje;

	private String detalles;

	private String httpCodeMessage;
	
	private List<Album> albums;

	public AlbumResponse(Date timestamp, String message, String details,
			String httpCodeMessage, List<Album> albums) {
	    super();
	    this.timestamp = timestamp;
	    this.mensaje = message;
	    this.detalles = details;
	    this.httpCodeMessage=httpCodeMessage;
	    this.albums = albums;
	}

	public String getHttpCodeMessage() {
		return httpCodeMessage;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public String getMensaje() {
		return mensaje;
	}

	public String getDetalles() {
		return detalles;
	}

	public List<Album> getAlbums() {
		return albums;
	}

	public void setAlbums(List<Album> albums) {
		this.albums = albums;
	}

}
