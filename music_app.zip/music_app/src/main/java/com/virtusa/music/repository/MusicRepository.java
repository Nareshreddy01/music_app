package com.virtusa.music.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.music.entity.Album;

@Repository
public interface MusicRepository extends JpaRepository<Album, String>, JpaSpecificationExecutor<Album> {
	
	@Transactional(readOnly = true)
	Album findByAlbumId(String albumId);
	
	@Transactional(readOnly = true)
	List<Album> findAll();

}
