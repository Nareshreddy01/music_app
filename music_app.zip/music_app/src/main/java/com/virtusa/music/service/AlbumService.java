package com.virtusa.music.service;
import java.util.List;

import com.virtusa.music.entity.Album;

public interface AlbumService {
	
	List<Album> getAlbums();
	
	Album saveAlbum(final Album album);
	
	Album updateAlbum(final String albumId);

}
