package com.virtusa.music.exception;
 
public class MusicCommonException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MusicCommonException(String message) {
		super(message);
	}
}
