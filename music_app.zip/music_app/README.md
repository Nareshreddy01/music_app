# Getting Started

### Reference Documentation
Application runs on tomcat port 8443 and uses h2 database.

Api-1: http://localhost:8443/music/artists - Save Artist details - {album pojo}
Api-2: http://localhost:8443/music/artists/1 - Update Artist details 
Api-3: http://localhost:8443/music/artists - Get All artists details

# Attached postman collection to test application